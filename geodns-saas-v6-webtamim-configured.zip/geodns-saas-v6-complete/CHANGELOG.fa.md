# Changelog - v0.3.0

## Added
- پشتیبانی از مدل واگذاری NS در دو حالت `platform` و `custom`
- پشتیبانی صریح از سناریوی GeoDNS برای `IR` و `INTL`
- پاسخ NS خودکار از روی تنظیمات zone در snapshot و DNS resolver
- عملیات `PATCH` و `DELETE` برای zone و record
- versioning برای snapshot و ثبت آخرین snapshot روی zone
- validation بهتر برای FQDN، رکورد A، MX، NS و CNAME conflict

## Changed
- نسخه API به `0.3.0` ارتقا یافت
- CORS و متدهای مجاز برای حالت SaaS کامل‌تر شد
- ساختار snapshot برای data plane غنی‌تر شد (`ns`, `geo_policy`, `version`)
- resolver برای apex NS و تفکیک IR/INTL بهینه‌تر شد

## Fixed
- جلوگیری از coexist بین CNAME و سایر رکوردها روی یک name
- جلوگیری از ثبت geo policy تکراری برای A record
- نرمال‌سازی بهتر zone/name/value برای پایداری بیشتر

## Next recommended work
- مهاجرت دیتابیس با Alembic
- auth پیشرفته‌تر شامل refresh token rotation
- rate limiting توزیع‌شده
- MaxMind واقعی برای تشخیص کشور
- replication/sync امن snapshot بین دو NS master
- Prometheus/Grafana + structured logging
