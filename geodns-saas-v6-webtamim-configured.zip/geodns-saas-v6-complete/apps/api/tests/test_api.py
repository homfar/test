def auth_header(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def test_bootstrap_login_and_zone_flow(client):
    r = client.post("/auth/bootstrap", json={"email": "admin@example.com", "password": "StrongPass123"})
    assert r.status_code == 200, r.text
    token = r.json()["access_token"]

    r = client.post("/auth/login", json={"email": "admin@example.com", "password": "StrongPass123"})
    assert r.status_code == 200
    token = r.json()["access_token"]

    r = client.post("/tenants", json={"name": "Acme", "slug": "acme"}, headers=auth_header(token))
    assert r.status_code == 200, r.text
    tenant_id = r.json()["id"]

    r = client.post(
        "/zones",
        json={
            "tenant_id": tenant_id,
            "name": "ipmyp.ir",
            "default_ttl": 300,
            "ns_mode": "custom",
            "custom_ns1": "ns1.ipmyp.ir.",
            "custom_ns2": "ns2.ipmyp.ir.",
            "platform_ns1": "mns1.provider.net.",
            "platform_ns2": "mns2.provider.net.",
        },
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text
    zone_id = r.json()["id"]
    assert r.json()["ns_mode"] == "custom"

    r = client.post(
        "/records",
        json={"zone_id": zone_id, "name": "@", "type": "A", "ttl": 300, "value": "185.7.172.136", "geo_country": "IR"},
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text

    r = client.post(
        "/records",
        json={"zone_id": zone_id, "name": "@", "type": "A", "ttl": 300, "value": "91.107.142.86", "geo_country": "INTL"},
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text

    r = client.post(
        "/records",
        json={"zone_id": zone_id, "name": "www", "type": "CNAME", "ttl": 300, "value": "ipmyp.ir."},
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text
    cname_id = r.json()["id"]

    r = client.patch(
        f"/records/{cname_id}",
        json={"is_enabled": False},
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text
    assert r.json()["is_enabled"] is False

    r = client.get(f"/zones/{zone_id}/records", headers=auth_header(token))
    assert r.status_code == 200
    assert len(r.json()) == 3

    r = client.post(f"/zones/{zone_id}/snapshot", headers=auth_header(token))
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["zone"] == "ipmyp.ir."
    assert body["version"] == 1
    assert body["ns"] == ["ns1.ipmyp.ir.", "ns2.ipmyp.ir."]
    assert len(body["records"]) == 2


def test_cname_conflict_is_rejected(client):
    r = client.post("/auth/bootstrap", json={"email": "admin@example.com", "password": "StrongPass123"})
    token = r.json()["access_token"]
    tenant_id = client.post("/tenants", json={"name": "Acme", "slug": "acme"}, headers=auth_header(token)).json()["id"]
    zone_id = client.post(
        "/zones",
        json={"tenant_id": tenant_id, "name": "example.com", "default_ttl": 300},
        headers=auth_header(token),
    ).json()["id"]

    r = client.post(
        "/records",
        json={"zone_id": zone_id, "name": "www", "type": "CNAME", "ttl": 300, "value": "example.com."},
        headers=auth_header(token),
    )
    assert r.status_code == 200

    r = client.post(
        "/records",
        json={"zone_id": zone_id, "name": "www", "type": "TXT", "ttl": 300, "value": "hello"},
        headers=auth_header(token),
    )
    assert r.status_code == 409


def test_snapshot_auto_sync_and_rbac(client):
    token = client.post("/auth/bootstrap", json={"email": "admin@example.com", "password": "StrongPass123"}).json()["access_token"]
    tenant_id = client.post("/tenants", json={"name": "Acme", "slug": "acme"}, headers=auth_header(token)).json()["id"]

    member = client.post(
        f"/tenants/{tenant_id}/members",
        json={"email": "editor@example.com", "password": "StrongPass123", "role": "editor"},
        headers=auth_header(token),
    )
    assert member.status_code == 200, member.text

    editor_token = client.post("/auth/login", json={"email": "editor@example.com", "password": "StrongPass123"}).json()["access_token"]

    secondary_dir = "/tmp/geodns_secondary"
    zone = client.post(
        "/zones",
        json={
            "tenant_id": tenant_id,
            "name": "example.com",
            "default_ttl": 300,
            "sync_mode": "push-secondary",
            "auto_sync_enabled": True,
            "secondary_snapshot_dir": secondary_dir,
            "sync_peer_label": "ns2",
        },
        headers=auth_header(editor_token),
    )
    assert zone.status_code == 200, zone.text
    zone_id = zone.json()["id"]

    rec = client.post(
        "/records",
        json={"zone_id": zone_id, "name": "@", "type": "A", "ttl": 300, "value": "1.1.1.1", "geo_country": "INTL"},
        headers=auth_header(editor_token),
    )
    assert rec.status_code == 200, rec.text

    snap = client.post(f"/zones/{zone_id}/snapshot", headers=auth_header(editor_token))
    assert snap.status_code == 200, snap.text
    assert snap.json()["sync"]["status"] == "success"

    import os
    assert os.path.exists(f"{secondary_dir}/example_com.json")

    denied = client.delete(f"/zones/{zone_id}", headers=auth_header(editor_token))
    assert denied.status_code == 403


def test_runtime_settings_maxmind_modes(client):
    token = client.post("/auth/bootstrap", json={"email": "admin@example.com", "password": "StrongPass123"}).json()["access_token"]

    r = client.get("/settings/runtime", headers=auth_header(token))
    assert r.status_code == 200, r.text
    assert r.json()["maxmind"]["mode"] == "manual"

    r = client.put(
        "/settings/runtime",
        json={
            "maxmind": {
                "mode": "auto",
                "account_id": "12345",
                "license_key": "secret-license",
                "edition_id": "GeoLite2-Country",
                "db_dir": "/app/maxmind",
                "auto_update_enabled": True,
                "auto_update_interval_hours": 12,
            }
        },
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["maxmind"]["mode"] == "auto"
    assert body["maxmind"]["db_path"] == "/app/maxmind/GeoLite2-Country.mmdb"

    r = client.put(
        "/settings/runtime",
        json={
            "maxmind": {
                "mode": "manual",
                "db_dir": "/app/maxmind",
                "db_path": "/app/maxmind/manual/GeoLite2-Country.mmdb",
                "auto_update_enabled": False,
                "auto_update_interval_hours": 24,
            }
        },
        headers=auth_header(token),
    )
    assert r.status_code == 200, r.text
    assert r.json()["maxmind"]["mode"] == "manual"
    assert r.json()["maxmind"]["db_path"] == "/app/maxmind/manual/GeoLite2-Country.mmdb"
