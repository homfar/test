import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

TEST_DB = "/tmp/geodns_api_test.db"
SNAPSHOT_DIR = "/tmp/geodns_snapshots"
os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB}"
os.environ["SNAPSHOT_DIR"] = SNAPSHOT_DIR
os.environ["JWT_SECRET"] = "test-secret"

from app.db import Base, engine  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(autouse=True)
def reset_db():
    engine.dispose()
    Path(TEST_DB).unlink(missing_ok=True)
    Path(SNAPSHOT_DIR).mkdir(parents=True, exist_ok=True)
    for p in Path(SNAPSHOT_DIR).glob("*.json"):
        p.unlink()
    runtime_settings = Path(SNAPSHOT_DIR) / "runtime-settings.json"
    runtime_settings.unlink(missing_ok=True)
    Base.metadata.create_all(bind=engine)
    yield
    engine.dispose()


@pytest.fixture()
def client():
    with TestClient(app) as c:
        yield c
