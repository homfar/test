from contextlib import asynccontextmanager
from datetime import datetime
import json

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .audit import write_audit
from .config import settings
from .db import Base, engine, get_db
from .deps import get_current_user, require_superuser, require_tenant_access, require_zone_access
from .models import DNSRecord, Membership, Tenant, User, Zone
from .schemas import (
    BootstrapRequest,
    HealthResponse,
    LoginRequest,
    MembershipCreate,
    MembershipResponse,
    MeResponse,
    RecordCreate,
    RecordResponse,
    RecordUpdate,
    SnapshotResponse,
    TenantCreate,
    TenantResponse,
    TokenResponse,
    ZoneCreate,
    ZoneResponse,
    ZoneUpdate,
)
from .runtime_settings import RuntimeSettings, load_runtime_settings, save_runtime_settings
from .security import create_access_token, hash_password, verify_password
from .settings_schemas import RuntimeSettingsPayload
from .snapshot import build_snapshot, persist_snapshot


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title=settings.app_name, version="0.6.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.cors_origins.split(",") if x.strip()],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    if settings.app_env != "development":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse()


@app.post("/auth/bootstrap", response_model=TokenResponse)
def bootstrap(payload: BootstrapRequest, db: Session = Depends(get_db)):
    first_user = db.query(User).first()
    if first_user:
        raise HTTPException(status_code=409, detail="Bootstrap already completed")
    user = User(email=payload.email.lower(), password_hash=hash_password(payload.password), is_superuser=True)
    db.add(user)
    write_audit(db, user, "bootstrap", "user", None, {"email": user.email})
    db.commit()
    db.refresh(user)
    return TokenResponse(access_token=create_access_token(user.id))


@app.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email.lower()).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return TokenResponse(access_token=create_access_token(user.id))


@app.get("/me", response_model=MeResponse)
def me(user: User = Depends(get_current_user)):
    return MeResponse(id=user.id, email=user.email, is_superuser=user.is_superuser)




@app.get("/settings/runtime", response_model=RuntimeSettings)
def get_runtime_settings(user: User = Depends(require_superuser)):
    return load_runtime_settings()


@app.put("/settings/runtime", response_model=RuntimeSettings)
def update_runtime_settings(payload: RuntimeSettingsPayload, db: Session = Depends(get_db), user: User = Depends(require_superuser)):
    runtime_settings = RuntimeSettings.model_validate(payload.model_dump())
    save_runtime_settings(runtime_settings)
    write_audit(db, user, "settings.runtime.update", "settings", "runtime", payload.model_dump())
    db.commit()
    return runtime_settings

@app.get("/tenants", response_model=list[TenantResponse])
def list_tenants(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.is_superuser:
        return db.query(Tenant).order_by(Tenant.created_at.desc()).all()
    tenant_ids = db.query(Membership.tenant_id).filter(Membership.user_id == user.id)
    return db.query(Tenant).filter(Tenant.id.in_(tenant_ids)).order_by(Tenant.created_at.desc()).all()


@app.post("/tenants", response_model=TenantResponse)
def create_tenant(payload: TenantCreate, db: Session = Depends(get_db), user: User = Depends(require_superuser)):
    tenant = Tenant(name=payload.name, slug=payload.slug)
    db.add(tenant)
    db.flush()
    db.add(Membership(user_id=user.id, tenant_id=tenant.id, role="owner"))
    write_audit(db, user, "tenant.create", "tenant", tenant.id, {"name": tenant.name, "slug": tenant.slug})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Tenant already exists") from exc
    db.refresh(tenant)
    return tenant


@app.get("/tenants/{tenant_id}/members", response_model=list[MembershipResponse])
def list_members(tenant_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    require_tenant_access(tenant_id, db, user, min_role="admin")
    return db.query(Membership).filter(Membership.tenant_id == tenant_id).order_by(Membership.created_at.desc()).all()


@app.post("/tenants/{tenant_id}/members", response_model=MembershipResponse)
def create_member(
    tenant_id: str,
    payload: MembershipCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    require_tenant_access(tenant_id, db, user, min_role="admin")
    member_user = db.query(User).filter(User.email == payload.email.lower()).first()
    if not member_user:
        member_user = User(email=payload.email.lower(), password_hash=hash_password(payload.password), is_superuser=False)
        db.add(member_user)
        db.flush()
    membership = Membership(user_id=member_user.id, tenant_id=tenant_id, role=payload.role)
    db.add(membership)
    write_audit(db, user, "membership.create", "tenant", tenant_id, {"email": payload.email.lower(), "role": payload.role})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Membership already exists") from exc
    db.refresh(membership)
    return membership


@app.get("/zones", response_model=list[ZoneResponse])
def list_zones(
    tenant_id: str = Query(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    require_tenant_access(tenant_id, db, user)
    return db.query(Zone).filter(Zone.tenant_id == tenant_id).order_by(Zone.created_at.desc()).all()


@app.post("/zones", response_model=ZoneResponse)
def create_zone(payload: ZoneCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    require_tenant_access(payload.tenant_id, db, user, min_role="editor")
    zone = Zone(
        tenant_id=payload.tenant_id,
        name=payload.name,
        default_ttl=payload.default_ttl,
        ns_mode=payload.ns_mode,
        geo_policy=payload.geo_policy,
        platform_ns1=payload.platform_ns1,
        platform_ns2=payload.platform_ns2,
        custom_ns1=payload.custom_ns1,
        custom_ns2=payload.custom_ns2,
        soa_email=payload.soa_email,
        sync_mode=payload.sync_mode,
        auto_sync_enabled=payload.auto_sync_enabled,
        secondary_snapshot_dir=payload.secondary_snapshot_dir,
        sync_peer_label=payload.sync_peer_label,
    )
    db.add(zone)
    write_audit(db, user, "zone.create", "zone", zone.id, {"name": zone.name, "ns_mode": zone.ns_mode})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Zone already exists for tenant") from exc
    db.refresh(zone)
    return zone


@app.patch("/zones/{zone_id}", response_model=ZoneResponse)
def update_zone(zone_id: str, payload: ZoneUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    zone = require_zone_access(zone_id, db, user, min_role="editor")
    updates = payload.model_dump(exclude_unset=True)
    if updates.get("ns_mode") == "custom":
        custom_ns1 = updates.get("custom_ns1", zone.custom_ns1)
        custom_ns2 = updates.get("custom_ns2", zone.custom_ns2)
        if not custom_ns1 or not custom_ns2:
            raise HTTPException(status_code=422, detail="custom_ns1 and custom_ns2 are required when ns_mode=custom")
    if updates.get("auto_sync_enabled") is True and updates.get("sync_mode", zone.sync_mode) != "push-secondary":
        raise HTTPException(status_code=422, detail="auto_sync_enabled requires sync_mode=push-secondary")
    if updates.get("sync_mode", zone.sync_mode) == "push-secondary":
        secondary_dir = updates.get("secondary_snapshot_dir", zone.secondary_snapshot_dir)
        if not secondary_dir:
            raise HTTPException(status_code=422, detail="secondary_snapshot_dir is required when sync_mode=push-secondary")
    for key, value in updates.items():
        setattr(zone, key, value)
    write_audit(db, user, "zone.update", "zone", zone.id, updates)
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Zone update conflicts with existing data") from exc
    db.refresh(zone)
    return zone


@app.delete("/zones/{zone_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_zone(zone_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    zone = require_zone_access(zone_id, db, user, min_role="admin")
    write_audit(db, user, "zone.delete", "zone", zone.id, {"name": zone.name})
    db.delete(zone)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get("/zones/{zone_id}/records", response_model=list[RecordResponse])
def list_records(zone_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    require_zone_access(zone_id, db, user)
    return db.query(DNSRecord).filter(DNSRecord.zone_id == zone_id).order_by(DNSRecord.created_at.desc()).all()


def _check_record_conflicts(db: Session, zone_id: str, name: str, type_: str, geo_country: str | None, record_id: str | None = None):
    query = db.query(DNSRecord).filter(DNSRecord.zone_id == zone_id, DNSRecord.name == name)
    if record_id:
        query = query.filter(DNSRecord.id != record_id)
    existing = query.all()
    if type_ == "CNAME" and existing:
        raise HTTPException(status_code=409, detail="CNAME cannot coexist with other record types on the same name")
    if type_ != "CNAME" and any(r.type == "CNAME" for r in existing):
        raise HTTPException(status_code=409, detail="Cannot add records beside an existing CNAME")
    if type_ == "A" and geo_country and any(r.type == "A" and r.geo_country == geo_country for r in existing):
        raise HTTPException(status_code=409, detail="Duplicate geo policy for this A record")


@app.post("/records", response_model=RecordResponse)
def create_record(payload: RecordCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    zone = require_zone_access(payload.zone_id, db, user, min_role="editor")
    _check_record_conflicts(db, zone.id, payload.name, payload.type.upper(), payload.geo_country)
    record = DNSRecord(
        zone_id=zone.id,
        name=payload.name,
        type=payload.type.upper(),
        ttl=payload.ttl,
        value=payload.value,
        priority=payload.priority,
        geo_country=payload.geo_country,
        is_enabled=payload.is_enabled,
    )
    db.add(record)
    write_audit(
        db,
        user,
        "record.create",
        "record",
        record.id,
        {"zone_id": zone.id, "name": record.name, "type": record.type, "geo_country": record.geo_country},
    )
    db.commit()
    db.refresh(record)
    return record


@app.patch("/records/{record_id}", response_model=RecordResponse)
def update_record(record_id: str, payload: RecordUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    record = db.get(DNSRecord, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    require_zone_access(record.zone_id, db, user, min_role="editor")
    updates = payload.model_dump(exclude_unset=True)
    if "name" in updates:
        updates["name"] = updates["name"].strip().lower().rstrip(".") or "@"
    if "value" in updates and record.type in {"CNAME", "NS", "MX"}:
        updates["value"] = updates["value"].strip().lower().rstrip(".") + "."
    if "geo_country" in updates and updates["geo_country"]:
        updates["geo_country"] = updates["geo_country"].strip().upper()
    check_name = updates.get("name", record.name)
    check_geo = updates.get("geo_country", record.geo_country)
    _check_record_conflicts(db, record.zone_id, check_name, record.type.upper(), check_geo, record_id=record.id)
    for key, value in updates.items():
        setattr(record, key, value)
    write_audit(db, user, "record.update", "record", record.id, updates)
    db.commit()
    db.refresh(record)
    return record


@app.delete("/records/{record_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_record(record_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    record = db.get(DNSRecord, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    require_zone_access(record.zone_id, db, user, min_role="admin")
    write_audit(db, user, "record.delete", "record", record.id, {"name": record.name, "type": record.type})
    db.delete(record)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.post("/zones/{zone_id}/snapshot", response_model=SnapshotResponse)
def compile_zone_snapshot(zone_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    zone = require_zone_access(zone_id, db, user, min_role="editor")
    snapshot = build_snapshot(zone, db)
    persist_result = persist_snapshot(snapshot, zone)
    zone.snapshot_version = int(snapshot["version"])
    zone.last_snapshot_path = persist_result["path"]
    zone.last_snapshot_at = datetime.fromisoformat(str(snapshot["generated_at"]).replace("Z", "+00:00"))
    zone.last_sync_status = persist_result["sync"]["status"]
    zone.last_sync_error = persist_result["sync"]["error"]
    write_audit(db, user, "snapshot.generate", "zone", zone.id, {"path": persist_result["path"], "version": snapshot["version"], "sync": persist_result["sync"]})
    db.commit()
    snapshot["sync"] = persist_result["sync"]
    return SnapshotResponse(**snapshot)


@app.get("/zones/{zone_id}/snapshot/download")
def download_snapshot(zone_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    zone = require_zone_access(zone_id, db, user)
    snapshot = build_snapshot(zone, db)
    snapshot["sync"] = {
        "enabled": zone.auto_sync_enabled,
        "mode": zone.sync_mode,
        "target": zone.secondary_snapshot_dir,
        "status": zone.last_sync_status or "disabled",
        "error": zone.last_sync_error,
    }
    filename = zone.name.replace('.', '_') + ".json"
    return Response(
        content=json.dumps(snapshot, ensure_ascii=False, indent=2),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/audit")
def list_audit(db: Session = Depends(get_db), user: User = Depends(require_superuser)):
    from .models import AuditLog

    return db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(100).all()
