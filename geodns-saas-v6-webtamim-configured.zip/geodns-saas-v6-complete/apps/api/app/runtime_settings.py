import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .config import settings


class MaxMindSettings(BaseModel):
    mode: str = Field(default="manual")
    account_id: str | None = None
    license_key: str | None = None
    edition_id: str = "GeoLite2-Country"
    db_dir: str = "/app/maxmind"
    db_path: str | None = None
    auto_update_enabled: bool = True
    auto_update_interval_hours: int = Field(default=24, ge=1, le=720)

    @model_validator(mode="after")
    def validate_model(self):
        self.mode = (self.mode or "manual").strip().lower()
        if self.mode not in {"disabled", "manual", "auto"}:
            raise ValueError("maxmind.mode must be one of disabled, manual, auto")
        if self.mode == "auto":
            if not self.account_id or not self.license_key:
                raise ValueError("maxmind account_id and license_key are required in auto mode")
        if self.db_path:
            self.db_path = self.db_path.strip()
        if not self.db_path:
            self.db_path = str(Path(self.db_dir) / f"{self.edition_id}.mmdb")
        return self


class RuntimeSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")

    maxmind: MaxMindSettings = Field(default_factory=MaxMindSettings)


DEFAULT_RUNTIME_SETTINGS = RuntimeSettings()


def runtime_settings_path() -> Path:
    return Path(settings.snapshot_dir) / "runtime-settings.json"


def load_runtime_settings() -> RuntimeSettings:
    path = runtime_settings_path()
    if not path.exists():
        return DEFAULT_RUNTIME_SETTINGS
    data = json.loads(path.read_text(encoding="utf-8"))
    return RuntimeSettings.model_validate(data)


def save_runtime_settings(runtime_settings: RuntimeSettings) -> dict[str, Any]:
    path = runtime_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    payload = runtime_settings.model_dump(mode="json")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
    return payload
