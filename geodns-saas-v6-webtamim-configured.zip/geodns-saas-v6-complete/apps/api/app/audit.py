import json
from sqlalchemy.orm import Session

from .models import AuditLog, User


def write_audit(db: Session, actor: User | None, action: str, resource_type: str, resource_id: str | None, details: dict) -> None:
    entry = AuditLog(
        actor_user_id=actor.id if actor else None,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details_json=json.dumps(details, ensure_ascii=False, sort_keys=True),
    )
    db.add(entry)
