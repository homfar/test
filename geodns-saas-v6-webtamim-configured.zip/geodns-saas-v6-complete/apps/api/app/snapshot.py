import json
import shutil
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy.orm import Session

from .config import settings
from .models import DNSRecord, Zone


def effective_ns(zone: Zone) -> list[str]:
    if zone.ns_mode == "custom" and zone.custom_ns1 and zone.custom_ns2:
        return [zone.custom_ns1, zone.custom_ns2]
    return [zone.platform_ns1, zone.platform_ns2]


def build_snapshot(zone: Zone, db: Session) -> dict:
    records = db.query(DNSRecord).filter(DNSRecord.zone_id == zone.id, DNSRecord.is_enabled.is_(True)).all()
    return {
        "zone": zone.name.rstrip(".").lower() + ".",
        "generated_at": datetime.now(UTC).isoformat(),
        "version": zone.snapshot_version + 1,
        "geo_policy": zone.geo_policy,
        "ns": effective_ns(zone),
        "soa_email": zone.soa_email,
        "records": [
            {
                "name": record.name,
                "type": record.type.upper(),
                "ttl": record.ttl,
                "value": record.value,
                "priority": record.priority,
                "geo_country": record.geo_country,
            }
            for record in records
        ],
    }


def _atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp_path.replace(path)


def _snapshot_filename(snapshot: dict) -> str:
    return snapshot["zone"].rstrip(".").replace(".", "_") + ".json"


def persist_snapshot(snapshot: dict, zone: Zone | None = None) -> dict:
    filename = _snapshot_filename(snapshot)
    primary_dir = Path(settings.snapshot_dir)
    primary_path = primary_dir / filename
    _atomic_write_json(primary_path, snapshot)

    sync_result = {
        "enabled": bool(zone and zone.auto_sync_enabled),
        "mode": zone.sync_mode if zone else "manual",
        "target": zone.secondary_snapshot_dir if zone else None,
        "status": "disabled" if not zone or not zone.auto_sync_enabled else "success",
        "error": None,
    }

    if zone and zone.auto_sync_enabled and zone.sync_mode == "push-secondary" and zone.secondary_snapshot_dir:
        try:
            secondary_path = Path(zone.secondary_snapshot_dir) / filename
            secondary_path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = secondary_path.with_suffix(secondary_path.suffix + ".tmp")
            shutil.copy2(primary_path, tmp_path)
            tmp_path.replace(secondary_path)
        except Exception as exc:
            sync_result["status"] = "failed"
            sync_result["error"] = str(exc)

    return {"path": str(primary_path), "sync": sync_result}
