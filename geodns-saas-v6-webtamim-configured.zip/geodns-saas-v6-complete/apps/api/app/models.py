import uuid
from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


DEFAULT_NS_MODE = "platform"
DEFAULT_GEO_POLICY = "ir-intl"
DEFAULT_SYNC_MODE = "manual"
DEFAULT_ROLE = "owner"


def uuid_str() -> str:
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_superuser: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC))

    memberships = relationship("Membership", back_populates="user", cascade="all, delete-orphan")


class Tenant(Base):
    __tablename__ = "tenants"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    name: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC))

    memberships = relationship("Membership", back_populates="tenant", cascade="all, delete-orphan")
    zones = relationship("Zone", back_populates="tenant", cascade="all, delete-orphan")


class Membership(Base):
    __tablename__ = "memberships"
    __table_args__ = (UniqueConstraint("user_id", "tenant_id", name="uq_membership_user_tenant"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(32), default=DEFAULT_ROLE)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC))

    user = relationship("User", back_populates="memberships")
    tenant = relationship("Tenant", back_populates="memberships")


class Zone(Base):
    __tablename__ = "zones"
    __table_args__ = (UniqueConstraint("tenant_id", "name", name="uq_zone_tenant_name"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    default_ttl: Mapped[int] = mapped_column(Integer, default=300)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    ns_mode: Mapped[str] = mapped_column(String(32), default=DEFAULT_NS_MODE)
    geo_policy: Mapped[str] = mapped_column(String(32), default=DEFAULT_GEO_POLICY)
    platform_ns1: Mapped[str] = mapped_column(String(255), default="ns1.geodns.local.")
    platform_ns2: Mapped[str] = mapped_column(String(255), default="ns2.geodns.local.")
    custom_ns1: Mapped[str | None] = mapped_column(String(255), nullable=True)
    custom_ns2: Mapped[str | None] = mapped_column(String(255), nullable=True)
    soa_email: Mapped[str] = mapped_column(String(255), default="hostmaster.geodns.local.")
    sync_mode: Mapped[str] = mapped_column(String(32), default=DEFAULT_SYNC_MODE)
    auto_sync_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    secondary_snapshot_dir: Mapped[str | None] = mapped_column(String(512), nullable=True)
    sync_peer_label: Mapped[str | None] = mapped_column(String(120), nullable=True)
    last_sync_status: Mapped[str | None] = mapped_column(String(32), nullable=True)
    last_sync_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    snapshot_version: Mapped[int] = mapped_column(Integer, default=0)
    last_snapshot_path: Mapped[str | None] = mapped_column(String(512), nullable=True)
    last_snapshot_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC))

    tenant = relationship("Tenant", back_populates="zones")
    records = relationship("DNSRecord", back_populates="zone", cascade="all, delete-orphan")


class DNSRecord(Base):
    __tablename__ = "dns_records"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    zone_id: Mapped[str] = mapped_column(ForeignKey("zones.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    type: Mapped[str] = mapped_column(String(16), index=True)
    ttl: Mapped[int] = mapped_column(Integer, default=300)
    value: Mapped[str] = mapped_column(Text)
    priority: Mapped[int | None] = mapped_column(Integer, nullable=True)
    geo_country: Mapped[str | None] = mapped_column(String(8), nullable=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC))

    zone = relationship("Zone", back_populates="records")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    actor_user_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(120), index=True)
    resource_type: Mapped[str] = mapped_column(String(64), index=True)
    resource_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    details_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC), index=True)
