from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from .db import get_db
from .models import Membership, Tenant, User, Zone
from .security import decode_access_token

bearer_scheme = HTTPBearer(auto_error=False)
ROLE_RANK = {"viewer": 10, "editor": 20, "admin": 30, "owner": 40}


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")
    try:
        payload = decode_access_token(credentials.credentials)
    except ValueError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    user = db.get(User, payload.get("sub"))
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Inactive user")
    return user


def require_superuser(user: User = Depends(get_current_user)) -> User:
    if not user.is_superuser:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Superuser required")
    return user


def get_membership(tenant_id: str, db: Session, user: User) -> Membership | None:
    return db.query(Membership).filter(Membership.user_id == user.id, Membership.tenant_id == tenant_id).first()


def require_tenant_access(tenant_id: str, db: Session, user: User, min_role: str = "viewer") -> Tenant:
    tenant = db.get(Tenant, tenant_id)
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    if user.is_superuser:
        return tenant
    membership = get_membership(tenant_id, db, user)
    if not membership:
        raise HTTPException(status_code=403, detail="No tenant access")
    if ROLE_RANK.get(membership.role, 0) < ROLE_RANK[min_role]:
        raise HTTPException(status_code=403, detail=f"{min_role} role required")
    return tenant


def require_zone_access(zone_id: str, db: Session, user: User, min_role: str = "viewer") -> Zone:
    zone = db.get(Zone, zone_id)
    if not zone:
        raise HTTPException(status_code=404, detail="Zone not found")
    require_tenant_access(zone.tenant_id, db, user, min_role=min_role)
    return zone
