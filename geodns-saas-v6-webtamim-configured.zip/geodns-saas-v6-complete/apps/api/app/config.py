from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "GeoDNS SaaS API"
    app_env: str = "development"
    database_url: str = "sqlite:///./geodns.db"
    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    cors_origins: str = "http://localhost:8081,http://localhost:5173"
    snapshot_dir: str = "/app/snapshots"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
