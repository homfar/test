from pydantic import BaseModel, Field


class MaxMindSettingsPayload(BaseModel):
    mode: str = Field(default="manual")
    account_id: str | None = Field(default=None, max_length=128)
    license_key: str | None = Field(default=None, max_length=256)
    edition_id: str = Field(default="GeoLite2-Country", max_length=128)
    db_dir: str = Field(default="/app/maxmind", max_length=512)
    db_path: str | None = Field(default=None, max_length=512)
    auto_update_enabled: bool = True
    auto_update_interval_hours: int = Field(default=24, ge=1, le=720)


class RuntimeSettingsPayload(BaseModel):
    maxmind: MaxMindSettingsPayload
