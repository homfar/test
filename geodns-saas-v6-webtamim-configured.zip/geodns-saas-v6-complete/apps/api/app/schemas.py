from datetime import datetime
from ipaddress import ip_address
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator

ALLOWED_RECORD_TYPES = {"A", "CNAME", "TXT", "MX", "NS"}
ALLOWED_NS_MODES = {"platform", "custom"}
ALLOWED_GEO_POLICIES = {"ir-intl", "country"}
ALLOWED_GEO_CODES = {"IR", "INTL"}
ALLOWED_SYNC_MODES = {"manual", "push-secondary"}
ALLOWED_MEMBERSHIP_ROLES = {"owner", "admin", "editor", "viewer"}


def normalize_hostname(value: str) -> str:
    value = value.strip().lower().rstrip(".")
    return value + "."


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = "0.4.0"


class BootstrapRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class MeResponse(BaseModel):
    id: str
    email: EmailStr
    is_superuser: bool


class TenantCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    slug: str = Field(min_length=2, max_length=120, pattern=r"^[a-z0-9-]+$")


class TenantResponse(BaseModel):
    id: str
    name: str
    slug: str
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class MembershipCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    role: Literal["owner", "admin", "editor", "viewer"] = "viewer"


class MembershipResponse(BaseModel):
    id: str
    tenant_id: str
    user_id: str
    role: str

    model_config = ConfigDict(from_attributes=True)


class ZoneBase(BaseModel):
    name: str = Field(min_length=3, max_length=255)
    default_ttl: int = Field(default=300, ge=30, le=86400)
    ns_mode: Literal["platform", "custom"] = "platform"
    geo_policy: Literal["ir-intl", "country"] = "ir-intl"
    platform_ns1: str = Field(default="ns1.geodns.local.")
    platform_ns2: str = Field(default="ns2.geodns.local.")
    custom_ns1: str | None = None
    custom_ns2: str | None = None
    soa_email: str = Field(default="hostmaster.geodns.local.")
    sync_mode: Literal["manual", "push-secondary"] = "manual"
    auto_sync_enabled: bool = False
    secondary_snapshot_dir: str | None = Field(default=None, max_length=512)
    sync_peer_label: str | None = Field(default=None, max_length=120)

    @field_validator("name")
    @classmethod
    def validate_zone_name(cls, value: str) -> str:
        value = value.strip().lower().rstrip(".")
        if "." not in value:
            raise ValueError("Zone must be a valid FQDN")
        return value

    @field_validator("platform_ns1", "platform_ns2", "custom_ns1", "custom_ns2", "soa_email")
    @classmethod
    def validate_hostnames(cls, value: str | None) -> str | None:
        if value is None:
            return value
        return normalize_hostname(value)

    @field_validator("secondary_snapshot_dir")
    @classmethod
    def validate_secondary_snapshot_dir(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        if not value:
            return None
        return value.rstrip("/")

    @model_validator(mode="after")
    def validate_nameserver_mode(self):
        if self.ns_mode == "custom" and (not self.custom_ns1 or not self.custom_ns2):
            raise ValueError("custom_ns1 and custom_ns2 are required when ns_mode=custom")
        if self.auto_sync_enabled and self.sync_mode != "push-secondary":
            raise ValueError("auto_sync_enabled requires sync_mode=push-secondary")
        if self.sync_mode == "push-secondary" and not self.secondary_snapshot_dir:
            raise ValueError("secondary_snapshot_dir is required when sync_mode=push-secondary")
        return self


class ZoneCreate(ZoneBase):
    tenant_id: str


class ZoneUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=3, max_length=255)
    default_ttl: int | None = Field(default=None, ge=30, le=86400)
    ns_mode: Literal["platform", "custom"] | None = None
    geo_policy: Literal["ir-intl", "country"] | None = None
    platform_ns1: str | None = None
    platform_ns2: str | None = None
    custom_ns1: str | None = None
    custom_ns2: str | None = None
    soa_email: str | None = None
    sync_mode: Literal["manual", "push-secondary"] | None = None
    auto_sync_enabled: bool | None = None
    secondary_snapshot_dir: str | None = Field(default=None, max_length=512)
    sync_peer_label: str | None = Field(default=None, max_length=120)
    is_active: bool | None = None

    @field_validator("name")
    @classmethod
    def validate_zone_name(cls, value: str | None) -> str | None:
        if value is None:
            return value
        value = value.strip().lower().rstrip(".")
        if "." not in value:
            raise ValueError("Zone must be a valid FQDN")
        return value

    @field_validator("platform_ns1", "platform_ns2", "custom_ns1", "custom_ns2", "soa_email")
    @classmethod
    def validate_hostnames(cls, value: str | None) -> str | None:
        if value is None:
            return value
        return normalize_hostname(value)

    @field_validator("secondary_snapshot_dir")
    @classmethod
    def validate_secondary_snapshot_dir(cls, value: str | None) -> str | None:
        if value is None:
            return value
        value = value.strip()
        return value.rstrip("/") if value else None


class ZoneResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    default_ttl: int
    is_active: bool
    ns_mode: str
    geo_policy: str
    platform_ns1: str
    platform_ns2: str
    custom_ns1: str | None
    custom_ns2: str | None
    soa_email: str
    sync_mode: str
    auto_sync_enabled: bool
    secondary_snapshot_dir: str | None
    sync_peer_label: str | None
    last_sync_status: str | None
    last_sync_error: str | None
    snapshot_version: int
    last_snapshot_path: str | None

    model_config = ConfigDict(from_attributes=True)


class RecordBase(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    type: Literal["A", "CNAME", "TXT", "MX", "NS"]
    ttl: int = Field(default=300, ge=30, le=86400)
    value: str = Field(min_length=1, max_length=2048)
    priority: int | None = Field(default=None, ge=0, le=65535)
    geo_country: str | None = Field(default=None, min_length=2, max_length=8)
    is_enabled: bool = True

    @field_validator("name")
    @classmethod
    def normalize_name(cls, value: str) -> str:
        value = value.strip().lower().rstrip(".")
        return value or "@"

    @field_validator("geo_country")
    @classmethod
    def validate_geo_country(cls, value: str | None) -> str | None:
        if not value:
            return None
        value = value.strip().upper()
        if value not in ALLOWED_GEO_CODES and len(value) != 2:
            raise ValueError("geo_country must be IR, INTL, or a 2-letter ISO code")
        return value

    @field_validator("value")
    @classmethod
    def normalize_value(cls, value: str) -> str:
        return value.strip()

    @model_validator(mode="after")
    def validate_record_payload(self):
        if self.type == "A":
            ip_address(self.value)
        elif self.type in {"CNAME", "NS", "MX"}:
            self.value = normalize_hostname(self.value)
        if self.type == "MX" and self.priority is None:
            self.priority = 10
        if self.type != "MX":
            self.priority = None
        if self.type != "A":
            self.geo_country = None
        return self


class RecordCreate(RecordBase):
    zone_id: str


class RecordUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    ttl: int | None = Field(default=None, ge=30, le=86400)
    value: str | None = Field(default=None, min_length=1, max_length=2048)
    priority: int | None = Field(default=None, ge=0, le=65535)
    geo_country: str | None = Field(default=None, min_length=2, max_length=8)
    is_enabled: bool | None = None


class RecordResponse(BaseModel):
    id: str
    zone_id: str
    name: str
    type: str
    ttl: int
    value: str
    priority: int | None
    geo_country: str | None
    is_enabled: bool

    model_config = ConfigDict(from_attributes=True)


class SnapshotRecord(BaseModel):
    name: str
    type: str
    ttl: int
    value: str
    priority: int | None = None
    geo_country: str | None = None


class SnapshotSyncResult(BaseModel):
    enabled: bool
    mode: str
    target: str | None = None
    status: str
    error: str | None = None


class SnapshotResponse(BaseModel):
    zone: str
    generated_at: datetime
    version: int
    ns: list[str]
    geo_policy: str
    sync: SnapshotSyncResult
    records: list[SnapshotRecord]
