import json
from pathlib import Path

from dnslib import DNSRecord

from app.resolver import SnapshotResolver


class Handler:
    def __init__(self, ip: str):
        self.client_address = (ip, 0)


class StubMaxMind:
    def __init__(self, mapping=None):
        self.mapping = mapping or {}

    def lookup_country(self, ip: str):
        return self.mapping.get(ip)


def test_geo_a_resolution(tmp_path: Path):
    snapshot = {
        "zone": "ipmyp.ir.",
        "generated_at": "2026-03-08T00:00:00Z",
        "version": 1,
        "geo_policy": "ir-intl",
        "ns": ["ns1.ipmyp.ir.", "ns2.ipmyp.ir."],
        "records": [
            {"name": "@", "type": "A", "ttl": 300, "value": "185.7.172.136", "geo_country": "IR"},
            {"name": "@", "type": "A", "ttl": 300, "value": "91.107.142.86", "geo_country": "INTL"},
            {"name": "www", "type": "CNAME", "ttl": 300, "value": "ipmyp.ir."},
        ],
    }
    path = tmp_path / "ipmyp_ir.json"
    path.write_text(json.dumps(snapshot), encoding="utf-8")
    resolver = SnapshotResolver(str(path))

    request = DNSRecord.question("ipmyp.ir", qtype="A")
    reply = resolver.resolve(request, Handler("127.0.0.1"))
    assert str(reply.rr[0].rdata) == "185.7.172.136"

    reply = resolver.resolve(request, Handler("8.8.8.8"))
    assert str(reply.rr[0].rdata) == "91.107.142.86"


def test_apex_ns_resolution(tmp_path: Path):
    snapshot = {
        "zone": "ipmyp.ir.",
        "generated_at": "2026-03-08T00:00:00Z",
        "version": 1,
        "geo_policy": "ir-intl",
        "ns": ["ns1.ipmyp.ir.", "ns2.ipmyp.ir."],
        "records": [],
    }
    path = tmp_path / "ipmyp_ir.json"
    path.write_text(json.dumps(snapshot), encoding="utf-8")
    resolver = SnapshotResolver(str(path))

    request = DNSRecord.question("ipmyp.ir", qtype="NS")
    reply = resolver.resolve(request, Handler("8.8.8.8"))
    assert len(reply.rr) == 2
    assert str(reply.rr[0].rdata.label) == "ns1.ipmyp.ir."


def test_cname_resolution(tmp_path: Path):
    snapshot = {
        "zone": "ipmyp.ir.",
        "generated_at": "2026-03-08T00:00:00Z",
        "version": 1,
        "geo_policy": "ir-intl",
        "ns": ["ns1.ipmyp.ir.", "ns2.ipmyp.ir."],
        "records": [
            {"name": "www", "type": "CNAME", "ttl": 300, "value": "ipmyp.ir."},
        ],
    }
    path = tmp_path / "ipmyp_ir.json"
    path.write_text(json.dumps(snapshot), encoding="utf-8")
    resolver = SnapshotResolver(str(path))

    request = DNSRecord.question("www.ipmyp.ir", qtype="CNAME")
    reply = resolver.resolve(request, Handler("8.8.8.8"))
    assert str(reply.rr[0].rdata.label) == "ipmyp.ir."


def test_ir_cidr_resolution(tmp_path: Path):
    snapshot = {
        "zone": "ipmyp.ir.",
        "generated_at": "2026-03-08T00:00:00Z",
        "version": 1,
        "geo_policy": "ir-intl",
        "ns": ["ns1.ipmyp.ir.", "ns2.ipmyp.ir."],
        "records": [
            {"name": "@", "type": "A", "ttl": 300, "value": "185.7.172.136", "geo_country": "IR"},
            {"name": "@", "type": "A", "ttl": 300, "value": "91.107.142.86", "geo_country": "INTL"},
        ],
    }
    path = tmp_path / "ipmyp_ir.json"
    cidr_path = tmp_path / "ir.cidrs"
    path.write_text(json.dumps(snapshot), encoding="utf-8")
    cidr_path.write_text("5.52.0.0/14\n", encoding="utf-8")
    resolver = SnapshotResolver(str(path), ir_cidrs_file=str(cidr_path))

    request = DNSRecord.question("ipmyp.ir", qtype="A")
    reply = resolver.resolve(request, Handler("5.52.1.10"))
    assert str(reply.rr[0].rdata) == "185.7.172.136"


def test_maxmind_resolution_prefers_ir(tmp_path: Path):
    snapshot = {
        "zone": "ipmyp.ir.",
        "generated_at": "2026-03-08T00:00:00Z",
        "version": 1,
        "geo_policy": "ir-intl",
        "ns": ["ns1.ipmyp.ir.", "ns2.ipmyp.ir."],
        "records": [
            {"name": "@", "type": "A", "ttl": 300, "value": "185.7.172.136", "geo_country": "IR"},
            {"name": "@", "type": "A", "ttl": 300, "value": "91.107.142.86", "geo_country": "INTL"},
        ],
    }
    path = tmp_path / "ipmyp_ir.json"
    path.write_text(json.dumps(snapshot), encoding="utf-8")
    resolver = SnapshotResolver(str(path), maxmind_manager=StubMaxMind({"1.1.1.1": "IR", "8.8.8.8": "US"}))

    request = DNSRecord.question("ipmyp.ir", qtype="A")
    ir_reply = resolver.resolve(request, Handler("1.1.1.1"))
    intl_reply = resolver.resolve(request, Handler("8.8.8.8"))
    assert str(ir_reply.rr[0].rdata) == "185.7.172.136"
    assert str(intl_reply.rr[0].rdata) == "91.107.142.86"
