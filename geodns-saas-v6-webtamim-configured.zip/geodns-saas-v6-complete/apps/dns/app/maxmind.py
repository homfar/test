import gzip
import json
import logging
import os
import shutil
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import urlopen

try:
    import maxminddb
except Exception:  # pragma: no cover - optional at runtime during import failures
    maxminddb = None

LOGGER = logging.getLogger(__name__)


class MaxMindManager:
    def __init__(self, runtime_settings_file: str | None = None):
        self.runtime_settings_file = runtime_settings_file or os.getenv(
            "RUNTIME_SETTINGS_FILE", "/app/snapshots/runtime-settings.json"
        )
        self._reader = None
        self._reader_path = None
        self._reader_mtime = None
        self._last_auto_check = 0.0

    def _default_settings(self) -> dict[str, Any]:
        db_dir = os.getenv("MAXMIND_DB_DIR", "/app/maxmind")
        edition = os.getenv("MAXMIND_EDITION_ID", "GeoLite2-Country")
        return {
            "mode": os.getenv("MAXMIND_MODE", "manual").strip().lower(),
            "account_id": os.getenv("MAXMIND_ACCOUNT_ID"),
            "license_key": os.getenv("MAXMIND_LICENSE_KEY"),
            "edition_id": edition,
            "db_dir": db_dir,
            "db_path": os.getenv("MAXMIND_DB_PATH", str(Path(db_dir) / f"{edition}.mmdb")),
            "auto_update_enabled": os.getenv("MAXMIND_AUTO_UPDATE_ENABLED", "true").lower() == "true",
            "auto_update_interval_hours": int(os.getenv("MAXMIND_AUTO_UPDATE_INTERVAL_HOURS", "24") or "24"),
        }

    def load_settings(self) -> dict[str, Any]:
        settings = self._default_settings()
        path = Path(self.runtime_settings_file)
        if not path.exists():
            return settings
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            maxmind_settings = payload.get("maxmind") or {}
            settings.update({k: v for k, v in maxmind_settings.items() if v is not None})
        except Exception as exc:  # pragma: no cover - defensive log path
            LOGGER.warning("Failed to parse runtime settings %s: %s", path, exc)
        if not settings.get("db_path"):
            settings["db_path"] = str(Path(settings["db_dir"]) / f"{settings['edition_id']}.mmdb")
        return settings

    def _download_url(self, settings: dict[str, Any]) -> str:
        account = settings.get("account_id")
        license_key = settings.get("license_key")
        edition = settings.get("edition_id", "GeoLite2-Country")
        suffix = "tar.gz"
        return (
            f"https://download.maxmind.com/app/geoip_download?edition_id={edition}"
            f"&license_key={license_key}&suffix={suffix}&account_id={account}"
        )

    def _extract_mmdb(self, archive_path: Path, db_path: Path) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive_path, "r:gz") as tar:
            mmdb_members = [m for m in tar.getmembers() if m.name.endswith(".mmdb")]
            if not mmdb_members:
                raise FileNotFoundError("No .mmdb file found in MaxMind archive")
            member = mmdb_members[0]
            with tar.extractfile(member) as source, tempfile.NamedTemporaryFile(delete=False, dir=str(db_path.parent)) as tmp:
                if source is None:
                    raise FileNotFoundError("Failed to read .mmdb from archive")
                shutil.copyfileobj(source, tmp)
                temp_name = tmp.name
        Path(temp_name).replace(db_path)

    def ensure_database(self, force: bool = False) -> str | None:
        settings = self.load_settings()
        mode = (settings.get("mode") or "manual").lower()
        db_path = Path(settings["db_path"])
        if mode == "disabled":
            return None
        if mode == "manual":
            return str(db_path) if db_path.exists() else None
        if mode != "auto":
            return None
        if not settings.get("account_id") or not settings.get("license_key"):
            LOGGER.warning("MaxMind auto mode is enabled but credentials are incomplete")
            return str(db_path) if db_path.exists() else None
        interval_seconds = max(int(settings.get("auto_update_interval_hours") or 24), 1) * 3600
        if db_path.exists() and not force and (time.time() - db_path.stat().st_mtime) < interval_seconds:
            return str(db_path)
        if not force and (time.time() - self._last_auto_check) < min(interval_seconds, 3600):
            return str(db_path) if db_path.exists() else None
        self._last_auto_check = time.time()
        try:
            url = self._download_url(settings)
            with urlopen(url, timeout=60) as response, tempfile.NamedTemporaryFile(delete=False, suffix=".tar.gz") as tmp:
                shutil.copyfileobj(response, tmp)
                archive_path = Path(tmp.name)
            self._extract_mmdb(archive_path, db_path)
            archive_path.unlink(missing_ok=True)
            LOGGER.info("MaxMind database refreshed at %s", db_path)
            return str(db_path)
        except (URLError, OSError, tarfile.TarError, gzip.BadGzipFile, FileNotFoundError) as exc:
            LOGGER.warning("MaxMind automatic download failed: %s", exc)
            return str(db_path) if db_path.exists() else None

    def _open_reader(self, db_path: str) -> None:
        if maxminddb is None:
            LOGGER.warning("maxminddb package is not available; GeoIP lookup disabled")
            return
        path = Path(db_path)
        if not path.exists():
            return
        mtime = path.stat().st_mtime
        if self._reader and self._reader_path == db_path and self._reader_mtime == mtime:
            return
        if self._reader:
            try:
                self._reader.close()
            except Exception:
                pass
        self._reader = maxminddb.open_database(db_path)
        self._reader_path = db_path
        self._reader_mtime = mtime

    def lookup_country(self, client_ip: str) -> str | None:
        db_path = self.ensure_database()
        if not db_path:
            return None
        self._open_reader(db_path)
        if not self._reader:
            return None
        try:
            result = self._reader.get(client_ip)
        except ValueError:
            return None
        if not result:
            return None
        country = ((result.get("country") or {}).get("iso_code") or "").upper()
        return country or None
