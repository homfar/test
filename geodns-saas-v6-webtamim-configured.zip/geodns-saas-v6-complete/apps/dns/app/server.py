import logging
import os
import threading
import time

from dnslib.server import DNSServer

from .maxmind import MaxMindManager
from .resolver import SnapshotResolver

logging.basicConfig(
    level=getattr(logging, os.getenv("LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(message)s",
)

LOGGER = logging.getLogger(__name__)


def _maxmind_refresh_loop(manager: MaxMindManager):
    while True:
        try:
            manager.ensure_database()
        except Exception as exc:  # pragma: no cover - defensive runtime logging
            LOGGER.warning("MaxMind refresh loop error: %s", exc)
        time.sleep(3600)


def main():
    snapshot_file = os.getenv("SNAPSHOT_FILE", "/app/snapshots/ipmyp_ir.json")
    maxmind_manager = MaxMindManager()
    maxmind_manager.ensure_database()
    resolver = SnapshotResolver(snapshot_file, maxmind_manager=maxmind_manager)
    udp_server = DNSServer(resolver, port=53, address="0.0.0.0", tcp=False)
    tcp_server = DNSServer(resolver, port=53, address="0.0.0.0", tcp=True)
    udp_server.start_thread()
    tcp_server.start_thread()
    threading.Thread(target=_maxmind_refresh_loop, args=(maxmind_manager,), daemon=True).start()
    LOGGER.info("DNS started with snapshot %s", snapshot_file)
    while True:
        time.sleep(60)


if __name__ == "__main__":
    main()
