import ipaddress
import json
import os
from pathlib import Path

from dnslib import A, CNAME, MX, NS, TXT, QTYPE, RCODE, RR
from dnslib.server import BaseResolver

from .maxmind import MaxMindManager


class SnapshotResolver(BaseResolver):
    def __init__(self, snapshot_file: str, ir_cidrs_file: str | None = None, maxmind_manager: MaxMindManager | None = None):
        self.snapshot_file = snapshot_file
        self.ir_cidrs_file = ir_cidrs_file or os.getenv("IR_CIDRS_FILE")
        self.maxmind_manager = maxmind_manager or MaxMindManager()
        self.data = self._load_snapshot()
        self.zone_name = self.data["zone"].rstrip(".").lower() + "."
        self.zone_ns = [str(ns).rstrip(".").lower() + "." for ns in self.data.get("ns", [])]
        self.geo_policy = self.data.get("geo_policy", "ir-intl")
        self.ir_networks = self._load_ir_networks()

    def _load_snapshot(self) -> dict:
        path = Path(self.snapshot_file)
        if not path.exists():
            raise FileNotFoundError(f"Snapshot not found: {self.snapshot_file}")
        return json.loads(path.read_text(encoding="utf-8"))

    def _load_ir_networks(self) -> list[ipaddress._BaseNetwork]:
        if not self.ir_cidrs_file:
            return []
        path = Path(self.ir_cidrs_file)
        if not path.exists():
            return []
        networks = []
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            try:
                networks.append(ipaddress.ip_network(line, strict=False))
            except ValueError:
                continue
        return networks

    @staticmethod
    def normalize(name: str) -> str:
        return str(name).rstrip(".").lower() + "."

    def client_country(self, client_ip: str) -> str:
        try:
            ip_obj = ipaddress.ip_address(client_ip)
        except ValueError:
            return "ZZ"
        if ip_obj.is_private or ip_obj.is_loopback:
            return "IR"
        maxmind_country = self.maxmind_manager.lookup_country(client_ip)
        if maxmind_country == "IR":
            return "IR"
        if any(ip_obj in network for network in self.ir_networks):
            return "IR"
        if maxmind_country:
            return maxmind_country
        return "INTL"

    def _records_for_name(self, record_name: str, qtype: str, country: str) -> list[dict]:
        records = []
        for record in self.data.get("records", []):
            if record["name"].lower() != record_name.lower():
                continue
            if qtype != "ANY" and record["type"].upper() != qtype.upper():
                continue
            records.append(record)
        records.sort(key=lambda r: (0 if r.get("geo_country") == country else 1 if r.get("geo_country") is None else 2))
        return records

    def _add_ns_answers(self, reply, qname: str, ttl: int = 300):
        for ns in self.zone_ns:
            reply.add_answer(RR(qname, QTYPE.NS, ttl=ttl, rdata=NS(ns)))
        return reply

    def resolve(self, request, handler):
        reply = request.reply()
        qname = self.normalize(str(request.q.qname))
        qtype = QTYPE[request.q.qtype]
        client_ip = handler.client_address[0]

        if not qname.endswith(self.zone_name):
            reply.header.rcode = RCODE.REFUSED
            return reply

        relative_name = "@" if qname == self.zone_name else qname[: -len(self.zone_name)].rstrip(".")
        country = self.client_country(client_ip)
        policy_country = "IR" if country == "IR" else "INTL" if self.geo_policy == "ir-intl" else country

        if relative_name == "@" and qtype in {"NS", "ANY"} and self.zone_ns:
            return self._add_ns_answers(reply, qname)

        rows = self._records_for_name(relative_name, qtype, policy_country)

        if not rows:
            reply.header.rcode = RCODE.NXDOMAIN
            return reply

        if qtype == "A":
            geo_matches = [r for r in rows if r["type"] == "A" and (r.get("geo_country") == policy_country or r.get("geo_country") is None)]
            if geo_matches:
                chosen = geo_matches[0]
                reply.add_answer(RR(qname, QTYPE.A, ttl=int(chosen["ttl"]), rdata=A(chosen["value"])))
                return reply

        for row in rows:
            rtype = row["type"].upper()
            ttl = int(row["ttl"])
            if rtype == "A":
                reply.add_answer(RR(qname, QTYPE.A, ttl=ttl, rdata=A(row["value"])))
            elif rtype == "CNAME":
                reply.add_answer(RR(qname, QTYPE.CNAME, ttl=ttl, rdata=CNAME(row["value"])))
            elif rtype == "TXT":
                reply.add_answer(RR(qname, QTYPE.TXT, ttl=ttl, rdata=TXT(row["value"])))
            elif rtype == "NS":
                reply.add_answer(RR(qname, QTYPE.NS, ttl=ttl, rdata=NS(row["value"])))
            elif rtype == "MX":
                priority = int(row.get("priority") or 10)
                reply.add_answer(RR(qname, QTYPE.MX, ttl=ttl, rdata=MX(row["value"], priority=priority)))

        return reply
