# بررسی SaaS و ایرادات نسخه قبلی

## لیست 1: ایرادها و ریسک‌های نسخه قبلی
1. برای سناریوی production دو NS مادر، مدل صریح delegation و NS اختصاصی در zone وجود نداشت.
2. GeoDNS فقط با `geo_country` خام کار می‌کرد و سناریوی صریح `IR/INTL` برای SaaS استاندارد نشده بود.
3. عملیات update/delete برای zone و record وجود نداشت و این در SaaS واقعی مشکل عملیاتی می‌ساخت.
4. تعارض CNAME با سایر recordها کنترل نمی‌شد.
5. duplicate geo rule برای A record روی یک hostname قابل ثبت بود.
6. snapshot نسخه‌بندی نداشت و ردگیری آخرین publish ضعیف بود.
7. پاسخ NS apex به صورت self-managed و پایدار از snapshot تولید نمی‌شد.
8. readiness برای معماری دو سرور مجزا در اسناد و flow عملیاتی ناقص بود.
9. validation رکوردها برای IP/FQDN در حد production کامل نبود.
10. هنوز MaxMind واقعی، migration، rate limit، backup policy و observability کامل ندارد.

## لیست 2: موارد لازم برای توسعه production
1. Alembic migration و schema evolution بدون downtime
2. replication/sync snapshot بین دو سرور NS به صورت atomic و checksum-based
3. reverse proxy + TLS + WAF + trusted proxy headers
4. Redis برای rate limiting, cache و job queue
5. MaxMind یا geoip2 واقعی با auto-update database
6. metrics, tracing, audit export, alerting
7. per-tenant quotas, billing hooks, abuse protection
8. RBAC کامل‌تر برای owner/admin/editor/viewer
9. soft delete, recycle bin و rollback snapshot
10. CI/CD، SAST/DAST، image scanning و backup/restore runbook
