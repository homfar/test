# راهنمای نصب GeoDNS برای webtamim.com

## مشخصات آماده‌شده
- دامنه اصلی: `webtamim.com`
- NS مادر 1: `ns1.webtamim.com` → `91.107.142.86`
- NS مادر 2: `ns2.webtamim.com` → `62.60.203.120`
- پنل: `https://panel.webtamim.com`
- API: `https://api.webtamim.com`
- روش نصب: `docker compose`
- SSL: فعال

## فایل‌های مهمی که ویرایش شده‌اند
- `infra/docker-compose.yml`
- `infra/docker-compose.dual-ns.example.yml`
- `infra/.env.example`
- `infra/nginx.production.conf.example`
- `infra/nginx.webtamim.conf`
- `apps/web/index.html`
- `snapshots/webtamim_com.json`

## 1) پیش‌نیازهای DNS در رجیسترار
قبل از بالا آوردن سرویس، برای دامنه `webtamim.com` این Glue Recordها باید در رجیسترار ثبت شوند:

- `ns1.webtamim.com` → `91.107.142.86`
- `ns2.webtamim.com` → `62.60.203.120`

همچنین A recordهای زیر را در DNS فعلی یا پنل رجیسترار تنظیم کنید:

- `panel.webtamim.com` → آی‌پی سروری که Nginx و پنل روی آن اجرا می‌شود
- `api.webtamim.com` → همان آی‌پی سرور، یا آی‌پی جداگانه در صورت نیاز

## 2) نصب Docker
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y ca-certificates curl gnupg unzip
curl -fsSL https://get.docker.com | sh
sudo systemctl enable docker
sudo systemctl start docker
docker --version
docker compose version
```

## 3) استخراج پروژه
```bash
unzip geodns-saas-v6-webtamim-configured.zip
cd geodns-saas-v6-complete/infra
```

اگر بعد از unzip یک پوشهٔ میانی دیدی، وارد همان پوشه‌ای شو که فایل `docker-compose.yml` داخل `infra` آن قرار دارد.

## 4) ساخت فایل env
```bash
cp .env.example .env
nano .env
```

مقادیر پیشنهادی:
```env
POSTGRES_PASSWORD=change-this-now-to-a-strong-password
JWT_SECRET=replace-this-with-a-long-random-secret
MAXMIND_MODE=manual
MAXMIND_ACCOUNT_ID=
MAXMIND_LICENSE_KEY=
MAXMIND_EDITION_ID=GeoLite2-Country
MAXMIND_AUTO_UPDATE_INTERVAL_HOURS=24
```

## 5) اجرای سرویس‌ها
از داخل پوشه `infra`:
```bash
docker compose up -d --build
```

بررسی وضعیت:
```bash
docker compose ps
docker compose logs -f api
docker compose logs -f dns
```

## 6) نصب Nginx و SSL
```bash
sudo apt install -y nginx certbot python3-certbot-nginx
```

فایل کانفیگ آماده را کپی کن:
```bash
sudo cp nginx.webtamim.conf /etc/nginx/sites-available/geodns-webtamim.conf
sudo ln -s /etc/nginx/sites-available/geodns-webtamim.conf /etc/nginx/sites-enabled/geodns-webtamim.conf
sudo nginx -t
sudo systemctl reload nginx
```

حالا گواهی SSL بگیر:
```bash
sudo certbot --nginx -d panel.webtamim.com -d api.webtamim.com
```

بعد دوباره Nginx را reload کن:
```bash
sudo nginx -t && sudo systemctl reload nginx
```

## 7) فایروال
```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 53/tcp
sudo ufw allow 53/udp
sudo ufw enable
```

## 8) تست سرویس
تست API:
```bash
curl -I https://api.webtamim.com/health
```

تست پنل:
مرورگر را باز کن و برو به:
```text
https://panel.webtamim.com
```

تست DNS روی خود سرور:
```bash
dig @127.0.0.1 webtamim.com NS
dig @127.0.0.1 webtamim.com A
```

تست از بیرون سرور:
```bash
dig @91.107.142.86 webtamim.com NS
dig @62.60.203.120 webtamim.com NS
```

## 9) نکته مهم درباره snapshot اولیه
در فایل `snapshots/webtamim_com.json` فقط NSهای اولیه تنظیم شده‌اند تا سرویس DNS بدون خطا بالا بیاید.
یعنی برای رکوردهای `A`، `CNAME`، `MX` و بقیه، باید بعد از ورود به پنل، زون و رکوردهای واقعی خودت را ثبت کنی و snapshot جدید بسازی.

## 10) ورود اولیه به پنل
بعد از بالا آمدن سرویس، در پنل با ایمیل و رمز دلخواهت عملیات Bootstrap را انجام بده.
پنل به API این آدرس وصل شده است:
- `https://api.webtamim.com`

## 11) اگر می‌خواهی ns1 و ns2 روی دو سرور جدا باشند
فایل `infra/docker-compose.dual-ns.example.yml` هم با نام دامنهٔ تو تنظیم شده است، اما برای اجرای واقعی روی دو سرور باید publish پورت 53 فقط روی همان DNS node انجام شود و snapshot بین دو سرور sync شود.

## 12) پیشنهاد بعد از نصب
- فایل MaxMind را داخل پوشه `maxmind/` قرار بده یا از حالت `auto` استفاده کن.
- پورت‌های 8080 و 8081 فقط روی localhost bind شده‌اند و باید پشت Nginx بمانند.
- بعد از ساخت زون واقعی، یک snapshot جدید از داخل پنل تولید کن.
