# راهنمای نصب و اجرای GeoDNS SaaS روی سرور

## پیش‌نیازها
- Ubuntu 22.04 یا 24.04
- حداقل 2 vCPU و 4GB RAM برای تست / 4 vCPU و 8GB RAM برای استیجینگ
- دسترسی root یا sudo
- باز بودن پورت‌های 80, 443, 53/tcp, 53/udp

## نصب Docker و Compose
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y ca-certificates curl gnupg ufw
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
sudo systemctl enable docker
sudo systemctl start docker
sudo docker version
sudo docker compose version
```

## استقرار پروژه
```bash
unzip geodns-saas-v6-webtamim-configured.zip
cd geodns-saas-v6-complete/infra
cp .env.example .env
nano .env
docker compose up -d --build
```

## تنظیم متغیرها
فایل `.env`:
```env
POSTGRES_PASSWORD=change-this-now
JWT_SECRET=replace-with-a-long-random-secret
```

در deployment واقعی، رمزهای عبور و secretها را در secret manager نگه دارید.

## فعال‌سازی فایروال
```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 53/tcp
sudo ufw allow 53/udp
sudo ufw enable
```

## اجرای دو NS مادر
- روی سرور اول، `ns1` را publish کنید.
- روی سرور دوم، `ns2` را publish کنید.
- اگر دو سرور به هم دسترسی دارند، از `auto_sync_enabled=true` و `sync_mode=push-secondary` استفاده کنید.
- اگر دو سرور به هم دسترسی ندارند، snapshot را به‌صورت دستی یا با object storage توزیع کنید.

## رجیسترار و glue record
برای NS اختصاصی، در رجیسترار باید glue record ثبت شود:
- `ns1.webtamim.com -> 91.107.142.86`
- `ns2.webtamim.com -> 62.60.203.120`

## Nginx/TLS پیشنهادی
API و UI را پشت reverse proxy منتشر کنید و برای API rate limiting و TLS فعال کنید. نمونه کانفیگ در `infra/nginx.production.conf.example` آمده است.

## تست سلامت
```bash
docker compose ps
docker compose logs -f api
docker compose logs -f dns
```

## تست DNS
```bash
dig @127.0.0.1 webtamim.com NS
# یا
nslookup webtamim.com 127.0.0.1
```

## بکاپ
- از volume پایگاه داده بکاپ منظم بگیرید.
- از دایرکتوری snapshots نیز بکاپ گرفته شود.
- حداقل روزانه یک restore test انجام شود.

## نکات production
- TLS و HSTS فعال شود.
- پورت 8080 و 8081 مستقیم روی اینترنت باز نماند.
- MaxMind/GeoIP معتبر و به‌روز استفاده شود.
- مانیتورینگ و alerting روی healthcheck و serial snapshot فعال شود.
- برای سرویس enterprise از PostgreSQL managed، object storage و CI/CD امن استفاده شود.


## تنظیم MaxMind
- حالت manual: فایل `GeoLite2-Country.mmdb` را داخل پوشه `maxmind/` قرار دهید و در پنل بخش تنظیمات MaxMind روی `manual` بگذارید.
- حالت auto: در همان بخش `auto` را انتخاب کنید و `Account ID` و `License Key` را وارد کنید تا DNS node دیتابیس را دانلود کند.
- جزئیات بیشتر: `docs/maxmind.fa.md`
