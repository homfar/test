# راهنمای production برای دو NS مادر

## الگوی پیشنهادی
- `api` و `postgres` روی control plane
- دو سرور مجزا برای `ns1` و `ns2`
- هر دو NS فقط snapshot می‌خوانند و مستقیم به DB وصل نمی‌شوند
- snapshot باید با rsync/scp/object storage به هر دو NS توزیع شود

## مدل واگذاری zone
- `ns_mode=platform`:
  - zone با NSهای مادر پلتفرم بالا می‌آید
  - مناسب کاربرانی که می‌خواهند child zone را با NSهای شما delegate کنند
- `ns_mode=custom`:
  - برای هر zone می‌شود `custom_ns1` و `custom_ns2` تعریف کرد
  - پاسخ NS apex از همین مقادیر ساخته می‌شود

## GeoDNS پیشنهادی
- برای رکوردهای A:
  - `geo_country=IR` برای IP ایران
  - `geo_country=INTL` برای IP خارج
  - `geo_country=null` برای fallback عمومی

## نکات پایداری
- snapshot publish باید atomic باشد
- healthcheck جدا برای api/dns/db داشته باش
- time sync روی هر دو NS فعال باشد
- serial/version snapshot در مانیتورینگ چک شود
- لاگ query DNS را sampling-based نگه دار تا overload نشود
