# Notes

## چرا این نسخه بهتر از starter قبلی است؟
- فقط scaffold نیست؛ **test** دارد.
- مدل داده multi-tenant واقعی‌تر شده.
- snapshot compiler اضافه شده تا DNS مستقیم به DB وصل نباشد.
- audit log اضافه شده.
- auth تمیزتر و middleware امنیتی دارد.
- resolver از JSON snapshot می‌خواند و نسبت به خطاهای محیط production پایدارتر است.

## محدودیت‌های فعلی
- refresh token ندارد.
- حذف/ویرایش رکوردها اضافه نشده تا هسته ساده و stable بماند.
- rate limit توزیع‌شده و billing هنوز پیاده نشده.
- GeoIP واقعی MaxMind در DNS service این نسخه فعال نیست و برای تست، private IP را IR فرض می‌کند.

## پیشنهاد rollout
1. همین نسخه را staging بالا بیاور
2. migration و backup policy اضافه کن
3. reverse proxy + TLS بگذار
4. MaxMind را اضافه کن
5. alerting و health checks کامل کن
