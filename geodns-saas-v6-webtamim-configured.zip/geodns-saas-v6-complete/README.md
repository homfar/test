# GeoDNS SaaS v0.6.0

این نسخه برای سناریوی SaaS با **دو NS مادر**، **GeoDNS ایران/خارج**، **API + UI** و **آمادگی بیشتر برای production** بازبینی و تثبیت شده است.

## موارد اصلی پیاده‌سازی‌شده
- FastAPI API با JWT و مدل multi-tenant
- تنظیمات runtime برای MaxMind به صورت manual/auto از داخل پنل و API
- RBAC برای نقش‌های `owner/admin/editor/viewer`
- ساخت tenant، ساخت کاربر سایت و تخصیص دسترسی
- مدیریت zone و record با API
- پشتیبانی از `platform NS` و `custom NS`
- پشتیبانی از `IR/INTL` برای رکوردهای A
- دانلود خودکار MaxMind در حالت auto و استفاده از دیتابیس دستی در حالت manual
- ساخت snapshot نسخه‌بندی‌شده
- auto sync اختیاری به مسیر ثانویه برای سناریوی دو سرور متصل
- DNS resolver سبک و پایدار مبتنی بر snapshot
- UI واکنش‌گرا برای ادمین کل و سایت‌ها
- تست خودکار API و DNS

## وضعیت فعلی
- در این نسخه پشتیبانی عملیاتی MaxMind برای حالت manual و auto اضافه شده است.
- همچنان برای استقرار enterprise در مقیاس بالا، hardening شبکه، مانیتورینگ، secret rotation و CI/CD پیشرفته توصیه می‌شود.
- برای production واقعی‌تر هنوز این‌ها strongly recommended هستند:
  - reverse proxy + TLS + WAF
  - Alembic migrations
  - observability کامل و alerting
  - secret management
  - CI/CD و security scanning
  - sync امن شبکه‌ای با checksum/signature بین دو NS

## اجرا
```bash
cd infra
docker compose up --build
```

## جریان پیشنهادی
1. ادمین کل bootstrap شود
2. tenant ساخته شود
3. کاربر سایت با نقش مناسب ساخته شود
4. زون با `platform` یا `custom NS` ایجاد شود
5. رکوردهای `A` برای `IR` و `INTL` ثبت شوند
6. snapshot ساخته شود
7. در صورت اتصال دو سرور، `push-secondary` و `auto_sync_enabled=true` فعال شود

## تست‌ها
- `apps/api`: سه تست عبور کرده
- `apps/dns`: چهار تست عبور کرده
- گزارش‌ها در ریشه پروژه ذخیره شده‌اند

## ساختار
- `apps/api` → control plane
- `apps/dns` → authoritative data plane
- `apps/web` → responsive admin UI
- `infra` → docker compose
- `docs` → notes


## راهنمای نصب روی سرور
- `docs/install-server.fa.md`
- `infra/nginx.production.conf.example`

## MaxMind
- `docs/maxmind.fa.md`
- پنل وب: بخش `تنظیمات GeoIP / MaxMind`
- API: `GET /settings/runtime` و `PUT /settings/runtime`
