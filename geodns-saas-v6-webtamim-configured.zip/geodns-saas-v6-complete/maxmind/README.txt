Place MaxMind .mmdb files here when using manual mode.
In auto mode, the DNS service downloads GeoLite2-Country.mmdb into this folder.
